//{{NO_DEPENDENCIES}}
// Microsoft Visual C++���� ������ ���� �����Դϴ�.
// Resource.rc���� ���ǰ� �ֽ��ϴ�.
//
#define IDD_DIALOG1                     101
#define IDD_DIALOG2                     103
#define IDI_ICON1                       107
#define IDC_RADIO1                      1001
#define IDC_RADIO2                      1002
#define IDC_RADIO3                      1003
#define IDC_RADIO4                      1004
#define IDC_RADIO5                      1005
#define IDC_RADIO6                      1006
#define IDC_RADIO7                      1007
#define IDC_RADIO8                      1008
#define IDC_RADIO9                      1009
#define IDC_RADIO10                     1010
#define IDC_RADIO11                     1011
#define IDC_RADIO12                     1012
#define IDC_RADIO13                     1013
#define IDC_RADIO14                     1014
#define IDC_RADIO15                     1015
#define IDC_CHECK1                      1016
#define IDC_RADIO20                     1018
#define IDC_RADIO21                     1019
#define IDC_RADIO22                     1020
#define IDC_RADIO23                     1021
#define IDC_RADIO24                     1022
#define IDC_RADIO25                     1023
#define IDC_RADIO26                     1024
#define IDC_RADIO27                     1025
#define IDC_RADIO28                     1026
#define IDC_CHECK2                      1027
#define IDC_CHECK3                      1028
#define IDC_CHECK4                      1029

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        108
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
